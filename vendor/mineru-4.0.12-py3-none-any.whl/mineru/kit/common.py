"""Common helpers for mineru-kit commands."""

from __future__ import annotations

import zipfile
from pathlib import Path
from typing import Literal, TypeAlias

from ..filetypes import PARSEABLE_EXTENSIONS
from ..parser.base import ParseResult
from ..parser.writer import FileBasedDataWriter
from ..types import Tier
from ..utils.i18n import t

KitFormat = Literal["markdown", "middle_json", "zip"]
LocalTier: TypeAlias = Tier


PARSEABLE_SUFFIXES = frozenset(f".{ext}" for ext in PARSEABLE_EXTENSIONS)
OUTPUT_FILE_SUFFIXES = {
    "markdown": ".md",
    "middle_json": ".json",
    "zip": ".zip",
}


def expand_input_paths(inputs: list[str]) -> list[Path]:
    paths = [Path(raw).expanduser() for raw in inputs]
    expanded: list[Path] = []
    for path in paths:
        if path.is_dir():
            for child in sorted(path.iterdir()):
                if child.is_file() and child.suffix.lower() in PARSEABLE_SUFFIXES:
                    expanded.append(child)
        else:
            expanded.append(path)
    return expanded


def ensure_supported_inputs(paths: list[Path]) -> None:
    if not paths:
        raise ValueError(t("No input files found."))
    for path in paths:
        if not path.exists():
            raise FileNotFoundError(path)
        if path.is_dir():
            raise ValueError(t("Directory input must be expanded before validation: {path}", path=path))
        if path.suffix.lower() not in PARSEABLE_SUFFIXES:
            raise ValueError(t("Unsupported file type: {path}", path=path))


def is_output_path_file_like(path: Path) -> bool:
    if path.exists():
        return path.is_file()
    return path.suffix.lower() in OUTPUT_FILE_SUFFIXES.values()


def resolve_single_output_path(source: Path, output: Path, format: KitFormat) -> Path:
    if output.exists() and output.is_dir():
        return output / f"{source.stem}{OUTPUT_FILE_SUFFIXES[format]}"
    if not output.exists() and output.suffix == "":
        return output / f"{source.stem}{OUTPUT_FILE_SUFFIXES[format]}"
    return output


def resolve_batch_output_paths(paths: list[Path], output: Path, format: KitFormat) -> dict[Path, Path]:
    if any(path.parent == path for path in paths):
        raise ValueError(t("Invalid input path."))
    if len(paths) > 1 and is_output_path_file_like(output):
        raise ValueError(t("When input is multiple files or directories, --output must be a directory path."))

    destinations: dict[Path, Path] = {}
    seen: dict[Path, Path] = {}
    for source in paths:
        dest = (
            resolve_single_output_path(source, output, format)
            if len(paths) == 1
            else output / f"{source.stem}{OUTPUT_FILE_SUFFIXES[format]}"
        )
        if dest.resolve() == source.resolve():
            raise ValueError(t("Output path must not be the same as the input file: {path}", path=source))
        existing = seen.get(dest)
        if existing is not None:
            raise ValueError(
                t(
                    "Output name collision: {existing} and {source} both map to {dest}",
                    existing=existing.name,
                    source=source.name,
                    dest=dest,
                )
            )
        seen[dest] = source
        destinations[source] = dest
    return destinations


def build_remote_api_url(remote: bool, remote_url: str | None) -> str | None:
    if remote and remote_url:
        raise ValueError(t("--remote and --remote-url are mutually exclusive."))
    if remote_url:
        return remote_url
    if remote:
        return "https://mineru.net/api"
    return None


def save_parse_result(result: ParseResult, dest: Path, format: KitFormat) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if format == "markdown":
        _write_utf8_text(dest, result.markdown())
        return
    if format == "middle_json":
        _write_utf8_text(dest, result.to_json())
        return
    if format == "zip":
        tmp_dir = dest.parent / f".{dest.stem}"
        writer = FileBasedDataWriter(str(tmp_dir))
        result.save(writer)
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for child in sorted(tmp_dir.rglob("*")):
                if child.is_file():
                    zf.write(child, arcname=child.relative_to(tmp_dir).as_posix())
        for child in sorted(tmp_dir.rglob("*"), reverse=True):
            if child.is_file():
                child.unlink()
            else:
                child.rmdir()
        if tmp_dir.exists():
            tmp_dir.rmdir()
        return
    raise ValueError(t("Unsupported format: {format}", format=format))


def _write_utf8_text(path: Path, content: str) -> None:
    path.write_bytes(content.encode("utf-8", errors="replace"))


def parse_result_payload(path: Path, dest: Path, format: KitFormat) -> dict[str, str]:
    return {
        "input": str(path),
        "output": str(dest),
        "format": format,
    }

from __future__ import annotations

from functools import partial
from pathlib import Path
from typing import Literal, cast

import typer

from ...errors import MineruError
from ...filetypes import ensure_tier_supported_for_parse_extension, is_flash_only_parse_extension
from ...parser import MinerUApiParser
from ...parser import parse as local_parse
from ...parser.api_client import _V1APIError
from ...parser.page_range import normalize_page_range_input
from ...types import Tier, validate_tier
from ...utils.i18n import t
from ..common import (
    build_remote_api_url,
    ensure_supported_inputs,
    expand_input_paths,
    parse_result_payload,
    resolve_batch_output_paths,
    save_parse_result,
)
from ..errors import exit_with_message
from ..output import print_info, print_success


def parse_cmd(
    inputs: list[str] = typer.Argument(..., help=t("Input files or directories")),
    output: str = typer.Option(..., "-o", "--output", help=t("Output path; required")),
    pages: str | None = typer.Option(
        None,
        "-p",
        "--pages",
        help=t("PDF pages: '1-5,8', 'r3-r1' (counted from the end), or 'all'; default: all pages"),
    ),
    format: str = typer.Option(
        "markdown",
        "-f",
        "--format",
        help=t("Output format: markdown, middle_json, zip"),
    ),
    verbose: bool = typer.Option(False, "-v", "--verbose", help=t("Verbose output")),
    tier: str | None = typer.Option(None, "--tier", help=t("Parse tier: flash, basic, standard, advanced")),
    remote: bool = typer.Option(False, "--remote", help=t("Use mineru.net official remote parse service")),
    remote_url: str | None = typer.Option(None, "--remote-url", help=t("Use a custom remote parse service URL")),
    api_key: str | None = typer.Option(None, "--api-key", help=t("API key for remote parse service")),
    ocr_mode: str = typer.Option("auto", "--ocr-mode", help=t("OCR mode: auto, txt, ocr")),
    disable_image_analysis: bool = typer.Option(False, "--disable-image-analysis", help=t("Disable image analysis")),
) -> None:
    """Parse files or directories into markdown, middle JSON, or zip outputs."""
    try:
        pages = normalize_page_range_input(pages)
    except MineruError as exc:
        exit_with_message(exc.code, str(exc), "pages")
    output_format = cast(Literal["markdown", "middle_json", "zip"], format)
    parse_tier = cast(Tier | None, tier)
    parse_ocr_mode = cast(Literal["auto", "txt", "ocr"], ocr_mode)
    if not inputs:
        exit_with_message("invalid_request", t("At least one input path is required."), "inputs")
    api_url = build_remote_api_url(remote, remote_url)
    raw_paths = [Path(raw).expanduser() for raw in inputs]
    if any(path.is_dir() for path in raw_paths) and Path(output).expanduser().suffix:
        exit_with_message(
            "invalid_request",
            t("When input is multiple files or directories, --output must be a directory path."),
            "output",
        )
    has_directory_input = any(path.is_dir() for path in raw_paths)
    if len(raw_paths) > 1 and Path(output).expanduser().suffix:
        exit_with_message(
            "invalid_request",
            t("When input is multiple files or directories, --output must be a directory path."),
            "output",
        )
    paths = expand_input_paths(inputs)
    try:
        ensure_supported_inputs(paths)
        destinations = resolve_batch_output_paths(paths, Path(output).expanduser(), output_format)
    except Exception as exc:
        exit_with_message("invalid_request", str(exc))

    if api_url:
        parser = MinerUApiParser(api_url=api_url, api_key=api_key, tier=parse_tier, include_images=True)
        parse_one = partial(parser.parse, page_range=pages or "")
    else:
        is_batch = has_directory_input or len(paths) > 1

        def parse_one(path: Path) -> object:
            path_tier: Tier = validate_tier(parse_tier) if parse_tier is not None else "standard"
            if is_flash_only_parse_extension(path):
                if not is_batch and parse_tier is not None:
                    ensure_tier_supported_for_parse_extension(path_tier, path)
                path_tier = "flash"
            return local_parse(
                path,
                tier=path_tier,
                ocr_mode=parse_ocr_mode,
                image_analysis=not disable_image_analysis,
                page_range=pages or "",
            )

    for path in paths:
        try:
            result = parse_one(path)
            dest = destinations[path]
            save_parse_result(result, dest, output_format)
            if verbose:
                print_info(str(parse_result_payload(path, dest, output_format)))
        except (MineruError, _V1APIError) as exc:
            exit_with_message(exc.code, str(exc), exc.param)
        except Exception as exc:
            exit_with_message("parse_failed", t("Failed to parse {path}: {error}", path=path, error=exc))
    print_success(t("Parsed {count} input(s).", count=len(paths)))

"""`mineru-kit webui` 的轻量命令门面。"""

from __future__ import annotations

import importlib.util
import os
from importlib.metadata import version

import typer
from packaging.specifiers import SpecifierSet

from ...types import SERVER_TIERS, ServerTier
from ...utils.i18n import t
from ...utils.logger import configure_global_log_level
from ...utils.stdio import configure_standard_streams
from ..errors import exit_with_message


def _require_gradio_dependencies() -> None:
    """检查 Gradio 基础依赖，并在缺失时给出安装提示。"""
    if importlib.util.find_spec("gradio") is None:
        exit_with_message(
            "dependency_missing",
            t("Gradio is a base dependency; repair the installation with `pip install 'mineru'`."),
        )
    if version("gradio") not in SpecifierSet(">=6.8,<7"):
        exit_with_message(
            "dependency_incompatible",
            t("Gradio >=6.8,<7 is required; upgrade with `pip install --upgrade 'mineru'`."),
        )


def _validate_server_tier(value: str) -> ServerTier:
    """校验自动启动的本地 API server 能力档位。"""
    if value not in SERVER_TIERS:
        exit_with_message(
            "invalid_request",
            t(
                "Unsupported API server tier '{tier}'. Supported tiers: {tiers}",
                tier=value,
                tiers=", ".join(SERVER_TIERS),
            ),
            "api_server_tier",
        )
    return value  # type: ignore[return-value]


def _validate_positive_option(value: int, *, name: str) -> int:
    """校验本地托管服务使用的正整数参数。"""
    if value <= 0:
        exit_with_message("invalid_request", t("{name} must be greater than zero", name=name), name)
    return value


def _validate_server_port(value: int) -> int:
    """校验 Gradio 监听端口处于 TCP 有效范围。"""
    if value < 1 or value > 65535:
        exit_with_message("invalid_request", t("server_port must be between 1 and 65535"), "server_port")
    return value


def webui_cmd(
    api_url: str | None = typer.Option(None, "--api-url", help=t("External MinerU V1 API base URL")),
    api_key: str | None = typer.Option(None, "--api-key", help=t("Bearer API key; falls back to MINERU_API_KEY")),
    server_name: str = typer.Option("127.0.0.1", "--server-name", help=t("Web UI bind host")),
    server_port: int | None = typer.Option(
        None, "--server-port", help=t("Web UI bind port; omitted: auto-select from 7860 or GRADIO_SERVER_PORT")
    ),
    output_dir: str = typer.Option("./output", "--output-dir", help=t("Directory for Web UI artifacts")),
    max_pages: int | None = typer.Option(None, "--max-pages", help=t("Maximum pages per PDF conversion; omitted: unlimited")),
    enable_example: bool = typer.Option(True, "--enable-example/--no-enable-example", help=t("Show local examples")),
    enable_api: bool = typer.Option(True, "--enable-api/--no-enable-api", help=t("Expose the Gradio event API")),
    api_server_tier: str = typer.Option(
        "standard", "--api-server-tier", "--tier", help=t("Managed API server capability tier")
    ),
    api_server_concurrency: int = typer.Option(
        1, "--api-server-concurrency", "--concurrency", help=t("Managed server job concurrency")
    ),
    api_server_disable_image_analysis: bool = typer.Option(
        False,
        "--api-server-disable-image-analysis",
        "--disable-image-analysis",
        help=t("Disable managed server image analysis"),
    ),
    api_server_preload_models: bool = typer.Option(
        False, "--api-server-preload-models", "--preload-models", help=t("Preload managed server models")
    ),
) -> None:
    """启动基于 MinerU V1 API 的 Gradio 文档解析界面。"""
    _require_gradio_dependencies()
    if server_port is not None:
        _validate_server_port(server_port)
    if max_pages is not None:
        _validate_positive_option(max_pages, name="max_pages")
    _validate_positive_option(api_server_concurrency, name="api_server_concurrency")
    normalized_tier = _validate_server_tier(api_server_tier)

    from ..gradio.app import launch_gradio

    try:
        resolved_api_key = api_key if api_key is not None else os.environ.get("MINERU_API_KEY")
        launch_gradio(
            api_url=api_url,
            api_key=resolved_api_key,
            server_name=server_name,
            server_port=server_port,
            output_dir=output_dir,
            max_pages=max_pages,
            enable_example=enable_example,
            enable_api=enable_api,
            api_server_tier=normalized_tier,
            api_server_concurrency=api_server_concurrency,
            api_server_disable_image_analysis=api_server_disable_image_analysis,
            api_server_preload_models=api_server_preload_models,
        )
    except Exception as exc:
        exit_with_message("gradio_start_failed", str(exc))


def main() -> None:
    """以独立 console script 运行Web UI 命令。"""
    configure_standard_streams()
    configure_global_log_level()
    app = typer.Typer(add_completion=False)
    app.command(help=t("Start the Gradio document parsing web UI backed by the MinerU V1 API."))(webui_cmd)
    app()


__all__ = ["webui_cmd", "main"]
